/*
 * @Author: George Wu
 * @Date: 2020-07-28 15:34:16
 * @LastEditors: George Wu
 * @LastEditTime: 2020-07-28 16:01:13
 * @FilePath: \middleware\server.js
 */ 
const express = require('express');
const app = express();
const port = 3500;

app.all('*', function(req, res, next){
    res.header('Access-Control-Allow-Orign', "*");
    res.header('Access-Control-Allow-Headers', "X-Requested-with,Content-Type");
    res.header('Access-Control-Allow-Methods', "PUT,POST,GET");
    next();
});

app.get("/", function(req, res){
    var data = JSON.stringify({
        all: "12345",
        money: "1234567"
    });
    res.send(data);
});

app.get('/a', function(req, res){
    var data = JSON.stringify({
       shop: [
           {
               shopName: "飞机",
               price: "1234"
           },
           {
               shopName: '电脑',
               price: '111'
           }
       ]
    });
    res.send(data);
});

app.listen(port, () => console.log(`Example app listening on port ${port}!`));
