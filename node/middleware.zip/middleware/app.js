/*
 * @Author: George Wu
 * @Date: 2020-07-27 22:35:57
 * @LastEditors: George Wu
 * @LastEditTime: 2020-07-28 16:43:06
 * @FilePath: \middleware\app.js
 */ 
const express = require('express');
const app = express();
const router = require("./router");
app.engine('art', require('express-art-template'));
app.set('views', './views');
app.use("/", router);
app.listen(3300);